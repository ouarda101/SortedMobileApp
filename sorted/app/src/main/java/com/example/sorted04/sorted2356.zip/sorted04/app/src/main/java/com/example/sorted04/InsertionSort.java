package com.example.sorted04;

public class InsertionSort {

}
